# Jeeran API
### Installation

- Clone the repo
- Copy .env `cp .env.example .env`.
- Generate new encryption key by running `php artisan key:generate`.
- Edit `.env` with database name, user and password.
- Run `composer install`.
