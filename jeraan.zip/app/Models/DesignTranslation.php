<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DesignTranslation extends Model
{
    use HasFactory;
    protected $table = 'designs_translations';
}
